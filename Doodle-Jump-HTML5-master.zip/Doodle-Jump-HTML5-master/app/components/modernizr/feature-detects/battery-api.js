
// Battery API
// https://developer.mozilla.org/en/DOM/window.navigator.mozBattery
// By: Paul Sayre

Modernizr.addTest('battery',
	!!Modernizr.prefixed('battery', navigator)
);