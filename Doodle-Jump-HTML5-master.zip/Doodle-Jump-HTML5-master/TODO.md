TODO
====
Here is a little todo list for this awesome game.

MILESTONE 1
-----------
* ~~Game screen~~
* ~~Player, platforms~~
* ~~Keyboard input~~
* ~~Gravity~~
* ~~Platform bounce~~
* ~~Gameover~~
* ~~Elevation~~
* ~~Random platforms~~


MILESTONE 2
-----------
### From Teachers
* ~~Accelerometer~~
* ~~Menus~~
* ~~Score~~ / high score list
* ~~Special platforms~~
* ~~Obstacles~~
* ~~Moving platforms/obstacles~~
* ~~Coins~~
* ~~Items~~
* Screen interaction

### Our Ideas
* Motion blur
* Particle effects
* ~~Better game over~~
* Shaders
* Test for multiple platforms
* ~~Sound effects and music~~
* Jetpack
* Space background when player reaches some height
* DOM object pool
* ..

### TODO
* ~~cooler menus~~
* ~~fragile platform animation~~
* high scores (using existing system)
* ~~iPad and android test~~

BUGS
----
* ~~Collision detection is off after the camera moves~~
* Bad performance affecting game play
